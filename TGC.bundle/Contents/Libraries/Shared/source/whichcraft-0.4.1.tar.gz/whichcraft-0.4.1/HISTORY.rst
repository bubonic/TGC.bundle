History
=========

0.4.1 (2017-04-25)
---------------------

* Added tests to support Python 3.6


0.3.1 (2016-05-10)
---------------------

* Now testing for `which` directly, so we can support versions of Python 3 before 3.3 (@nickcoghlan)

0.3.1 (2016-04-24)
---------------------

* Correcting version in whichcraft.py

0.3.0 (2016-04-24)
---------------------

* Include tests in release source tarball (@Edwardbetts)

0.2.0 (2016-04-23)
---------------------

* Python 3.5 compatability

0.1.1 (2015-09-09)
---------------------

* Added lyrics

0.1.0 (2015-09-09)
---------------------

* First release on PyPI.
