from PilLite import Image

img = Image.open('/home/alexey/projects/imagineer/jpeg/test/functional/data/divine-flux.jpg')
print(img.size)
img.show()
